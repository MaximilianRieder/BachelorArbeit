Table temp = locationInfo.select("ORT_REF_ORT", "ORT_NR");
Table transferTimetable = temp.summarize("ORT_NR", count).by("ORT_REF_ORT");
transferTimetable = transferTimetable.sortAscendingOn("ORT_REF_ORT");
transferTimetable.doubleColumn("Count [ORT_NR]").setName("FREQ");